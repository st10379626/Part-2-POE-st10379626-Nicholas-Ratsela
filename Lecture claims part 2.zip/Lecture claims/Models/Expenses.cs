﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection.Metadata;

namespace Lecture_claims.Models
{
    public class Expenses
    {
        [Key]
        public int LectureID { get; set; }
        [NotMapped]//allow for claim numbering linked to Lecture ID
        public string FormattedLectureID => $"CL{LectureID:D2}";

        public string LectureName { get; set; } = "";

         public Document SupoortingDocuments { get; set; }
  
        public int Groups { get; set; }

        public int HourlyRate { get; set; }
        public int Total { get; set; }
        

        [Required]
        public string? Module { get; set; } = "";

        [Required]
        public int Numberofhours { get; set; }

        // [Required]
        //public string? Description { get; set; }


    }
}
