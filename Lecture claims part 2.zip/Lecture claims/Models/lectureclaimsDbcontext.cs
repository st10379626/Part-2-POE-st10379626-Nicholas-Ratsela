﻿using Microsoft.EntityFrameworkCore;

namespace Lecture_claims.Models
{
    public class lectureclaimsDbcontext : DbContext
    {
       public DbSet<Expenses> Expensess { get; set; }


        public lectureclaimsDbcontext(DbContextOptions<lectureclaimsDbcontext> options)
            :base(options)  
        {
                
        }


    }
}
